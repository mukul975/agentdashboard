import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Terminal, Maximize2, Minimize2, Download, RefreshCw, AlertCircle } from 'lucide-react';
import { apiFetch } from '../utils/api.js';
import { SkeletonOutputViewer } from './SkeletonLoader';
import { useTranslation } from "react-i18next";
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
dayjs.extend(relativeTime);

export function AgentOutputViewer({ agentOutputs }) {
  const { t } = useTranslation();
  const [selectedOutput, setSelectedOutput] = useState(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshError, setRefreshError] = useState(null);
  const [localOutputs, setLocalOutputs] = useState(agentOutputs || []);
  const outputRef = useRef(null);
  const pollingIntervalRef = useRef(null);
  const selectedOutputRef = useRef(null);

  // Fetch outputs from API
  const fetchOutputs = useCallback(async () => {
    try {
      setIsRefreshing(true);
      setRefreshError(null);

      const response = await apiFetch('/api/agent-outputs');

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();

      if (data.outputs && Array.isArray(data.outputs)) {
        setLocalOutputs(data.outputs);
        return data.outputs;
      } else {
        throw new Error('Invalid response format');
      }
    } catch (error) {
      console.error('Error fetching agent outputs:', error);
      setRefreshError(error.message);
      return null;
    } finally {
      setIsRefreshing(false);
    }
  }, []);

  // Manual refresh handler
  const handleManualRefresh = useCallback(async () => {
    await fetchOutputs();
  }, [fetchOutputs]);

  // Use WebSocket data when available, fallback to polling
  useEffect(() => {
    if (agentOutputs && agentOutputs.length > 0) {
      setLocalOutputs(agentOutputs);
      setRefreshError(null);
    }
  }, [agentOutputs]);

  // Fallback polling mechanism (only if no WebSocket data)
  useEffect(() => {
    // If we haven't received any data via WebSocket, start polling
    if (!agentOutputs || agentOutputs.length === 0) {
      // Initial fetch
      fetchOutputs();

      // Poll every 5 seconds as fallback
      pollingIntervalRef.current = setInterval(() => {
        fetchOutputs();
      }, 5000);
    } else {
      // Clear polling if WebSocket is working
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
        pollingIntervalRef.current = null;
      }
    }

    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [agentOutputs, fetchOutputs]);

  useEffect(() => {
    // Auto-select most recent output
    if (localOutputs && localOutputs.length > 0 && !selectedOutputRef.current) {
      const first = localOutputs[0];
      selectedOutputRef.current = first;
      setSelectedOutput(first);
      return;
    }

    // Update selected output if it exists in new data
    if (selectedOutputRef.current && localOutputs && localOutputs.length > 0) {
      const updatedOutput = localOutputs.find(o => o.taskId === selectedOutputRef.current.taskId);
      if (updatedOutput && updatedOutput.lastModified !== selectedOutputRef.current.lastModified) {
        selectedOutputRef.current = updatedOutput;
        setSelectedOutput(updatedOutput);
      }
    }
  }, [localOutputs]);

  useEffect(() => {
    // Auto-scroll to bottom when content updates
    if (autoScroll && outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight;
    }
  }, [selectedOutput, autoScroll]);

  const downloadOutput = () => {
    if (!selectedOutput) return;

    const blob = new Blob([selectedOutput.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `agent-${selectedOutput.taskId}-output.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  if ((!localOutputs || localOutputs.length === 0) && isRefreshing) {
    return <SkeletonOutputViewer />;
  }

  if (!localOutputs || localOutputs.length === 0) {
    return (
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Terminal className="h-5 w-5 text-claude-orange" />
            <h3 className="text-lg font-semibold" style={{ color: 'var(--text-heading)' }}>{t("agent_output.title")}</h3>
          </div>
          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-lg transition-colors"
            style={{ background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)', opacity: isRefreshing ? 0.5 : 1 }}
            aria-label={t("agent_output.refresh")}
            title={t("agent_output.refresh")}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {refreshError && (
          <div className="mb-4 p-3 rounded-lg flex items-start gap-2" style={{ background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)' }}>
            <AlertCircle className="h-5 w-5 text-red-400" style={{ flexShrink: 0, marginTop: '2px' }} />
            <div className="flex-1">
              <p className="text-sm text-red-400 font-medium">{t("agent_output.failed_to_load")}</p>
              <p className="text-xs mt-1" style={{ color: 'rgba(248,113,113,0.8)' }}>{refreshError}</p>
            </div>
          </div>
        )}

        <div className="text-center py-12" style={{ color: 'var(--text-muted)' }}>
          <Terminal className="h-16 w-16 mx-auto mb-3" style={{ opacity: 0.5 }} />
          <p className="text-sm">{t("agent_output.no_outputs")}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="card" style={isExpanded ? { position: 'fixed', inset: '16px', zIndex: 50 } : undefined}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Terminal className="h-5 w-5 text-claude-orange animate-pulse" />
          <h3 className="text-lg font-semibold" style={{ color: 'var(--text-heading)' }}>{t("agent_output.title")}</h3>
          <span className="px-2 text-green-400 text-xs rounded-full flex items-center gap-1" style={{ background: 'rgba(34,197,94,0.2)', border: '1px solid rgba(34,197,94,0.3)', paddingTop: '2px', paddingBottom: '2px' }}>
            <span className="rounded-full animate-pulse" style={{ height: '8px', width: '8px', backgroundColor: '#4ade80' }}></span>
            {t("live_metrics.live")}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="p-2 rounded-lg transition-colors"
            style={{ background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)', opacity: isRefreshing ? 0.5 : 1, cursor: isRefreshing ? 'not-allowed' : 'pointer' }}
            aria-label={t("agent_output.refresh")}
            title={t("agent_output.refresh")}
          >
            <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setAutoScroll(!autoScroll)}
            className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors ${autoScroll
                ? 'text-green-400'
                : ''
              }`}
            style={!autoScroll ? { background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)' } : { background: 'rgba(34,197,94,0.2)', border: '1px solid rgba(34,197,94,0.3)' }}
            aria-label={autoScroll ? t("agent_output.auto_scroll_enabled") : t("agent_output.enable_auto_scroll")}
            title={autoScroll ? t("agent_output.auto_scroll_enabled") : t("agent_output.enable_auto_scroll")}
          >
            {autoScroll ? 'Auto-scroll ON' : 'Auto-scroll OFF'}
          </button>
          <button
            onClick={downloadOutput}
            disabled={!selectedOutput}
            className="p-2 rounded-lg transition-colors"
            style={{ background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)', opacity: !selectedOutput ? 0.5 : 1, cursor: !selectedOutput ? 'not-allowed' : 'pointer' }}
            aria-label={t("agent_output.download")}
            title={t("agent_output.download")}
          >
            <Download className="h-4 w-4" />
          </button>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-lg transition-colors"
            style={{ background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)' }}
            aria-label={isExpanded ? t("agent_output.minimize") : t("agent_output.maximize")}
            aria-expanded={isExpanded}
            title={isExpanded ? t("agent_output.minimize") : t("agent_output.maximize")}
          >
            {isExpanded ? (
              <Minimize2 className="h-4 w-4" />
            ) : (
              <Maximize2 className="h-4 w-4" />
            )}
          </button>
        </div>
      </div>

      {/* Error Display */}
      {refreshError && (
        <div className="mb-4 p-3 rounded-lg flex items-start gap-2" style={{ background: 'rgba(234, 179, 8, 0.1)', border: '1px solid rgba(234, 179, 8, 0.3)' }}>
          <AlertCircle className="h-5 w-5 text-yellow-400" style={{ flexShrink: 0, marginTop: '2px' }} />
          <div className="flex-1">
            <p className="text-sm text-yellow-400 font-medium">{t("agent_output.connection_issue")}</p>
            <p className="text-xs mt-1" style={{ color: 'rgba(250,204,21,0.8)' }}>
              {refreshError} - Displaying cached data or using fallback polling
            </p>
          </div>
        </div>
      )}

      {/* Output Selector */}
      <div className="mb-4">
        <label className="text-sm mb-2" style={{ color: 'var(--text-secondary)', display: 'block' }}>{t("agent_output.select_agent")}</label>
        <div className="flex gap-2" style={{ overflowX: 'auto', paddingBottom: '8px' }}>
          {localOutputs.map((output, index) => (
            <button
              key={output.taskId}
              onClick={() => { selectedOutputRef.current = output; setSelectedOutput(output); }}
              aria-label={`View output for Task ${output.taskId}`}
              className={`rounded-lg text-sm font-medium ${selectedOutput?.taskId === output.taskId
                  ? 'bg-claude-orange text-white shadow-lg'
                  : ''
                }`}
              style={{
                padding: '8px 16px',
                whiteSpace: 'nowrap',
                transition: 'all 0.15s',
                ...(selectedOutput?.taskId !== output.taskId
                  ? { background: 'var(--bg-secondary)', color: 'var(--text-secondary)', border: '1px solid var(--border-color)', animation: `fadeInScale 0.3s ease-out ${index * 0.05}s backwards` }
                  : { animation: `fadeInScale 0.3s ease-out ${index * 0.05}s backwards` }
                )
              }}
            >
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4" />
                <span>{t("agent_output.task_prefix", { id: output.taskId })}</span>
              </div>
              <div className="text-xs" style={{ opacity: 0.75, marginTop: '2px' }}>
                {dayjs(output.lastModified).fromNow()}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Output Display */}
      {selectedOutput && (
        <>
          {/* Output Info */}
          <div className="mb-3 p-3 rounded-lg" style={{ background: 'var(--bg-secondary)', border: '1px solid var(--border-color)' }}>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span style={{ color: 'var(--text-muted)' }}>
                  Task ID: <span style={{ color: 'var(--text-primary)', fontFamily: 'monospace' }}>{selectedOutput.taskId}</span>
                </span>
                <span style={{ color: 'var(--text-muted)' }}>
                  Size: <span style={{ color: 'var(--text-primary)' }}>{formatSize(selectedOutput.size)}</span>
                </span>
              </div>
              <span style={{ color: 'var(--text-muted)' }}>
                Updated: <span style={{ color: 'var(--text-primary)' }}>{dayjs(selectedOutput.lastModified).fromNow()}</span>
              </span>
            </div>
          </div>

          {/* Terminal Output */}
          <div
            ref={outputRef}
            className="text-sm rounded-lg p-4"
            style={{ background: 'var(--code-bg)', border: '1px solid var(--code-border)', fontFamily: 'monospace', overflow: 'auto', height: isExpanded ? 'calc(100vh - 300px)' : '500px' }}
            onScroll={(e) => {
              const { scrollTop, scrollHeight, clientHeight } = e.target;
              const isAtBottom = Math.abs(scrollHeight - clientHeight - scrollTop) < 10;
              if (!isAtBottom && autoScroll) {
                setAutoScroll(false);
              }
            }}
          >
            {selectedOutput.content ? (
              <pre style={{ color: 'var(--text-primary)', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                {selectedOutput.content}
              </pre>
            ) : (
              <div className="text-center py-12" style={{ color: 'var(--text-muted)' }}>
                <Terminal className="mx-auto mb-3" style={{ height: '48px', width: '48px', opacity: 0.5 }} />
                <p className="text-sm font-medium mb-2">{t("agent_output.no_output_content")}</p>
                <p className="text-xs mx-auto" style={{ color: 'var(--text-muted)', maxWidth: '28rem' }}>
                  This task output is empty. Agent outputs will appear here when agents write to their output streams during task execution.
                </p>
                <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
                  Empty outputs are normal for agents that complete tasks quickly without verbose logging.
                </p>
              </div>
            )}
          </div>

          {/* Footer Info */}
          <div className="mt-3 text-xs text-center flex items-center gap-2" style={{ color: 'var(--text-muted)', justifyContent: 'center' }}>
            <span className="rounded-full animate-pulse" style={{ height: '8px', width: '8px', backgroundColor: '#4ade80' }}></span>
            <span>
              Real-time output from Claude Code agent • Updates via WebSocket
              {!agentOutputs || agentOutputs.length === 0 ? ' (fallback polling active)' : ''}
            </span>
          </div>
        </>
      )}
    </div>
  );
}
