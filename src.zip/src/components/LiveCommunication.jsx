import React, { useState, useEffect, useMemo } from 'react';
import { MessageSquare, Users, Clock, Bot, CheckCircle, AlertCircle, Zap, ChevronLeft, Layers, List } from 'lucide-react';
import { apiFetch } from '../utils/api.js';
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import { parseMessageToNatural } from '../utils/messageParser';
import { getInboxMessages } from '../utils/safeKey';
import { useTranslation } from 'react-i18next';
dayjs.extend(relativeTime);

const getIconComponent = (type) => {
  switch (type) {
    case 'completion': return CheckCircle;
    case 'system': return AlertCircle;
    case 'assignment': return Zap;
    case 'status': return Bot;
    default: return MessageSquare;
  }
};

function buildMessages(allInboxes, selectedTeam) {
  if (!selectedTeam) return [];
  const teamInboxes = allInboxes[selectedTeam] || {};
  return Object.entries(teamInboxes)
    .flatMap(([agentName, inbox]) => {
      const msgs = getInboxMessages(inbox);
      return msgs
        .filter(msg => msg != null)
        .map(msg => {
          const naturalMsg = parseMessageToNatural(msg.text, msg.summary); // lgtm[js/call-to-non-callable]
          return {
            id: `${agentName}-${msg.timestamp}-${(msg.text || '').slice(0, 8)}`,
            from: msg.from || agentName,
            to: agentName,
            message: naturalMsg.text,
            timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(0),
            type: naturalMsg.type,
            color: msg.color || 'blue',
            read: msg.read !== false,
          };
        });
    })
    .sort((a, b) => a.timestamp - b.timestamp)
    .slice(-50);
}

function buildThreads(messages) {
  const threadMap = {};
  messages.forEach(msg => {
    const pair = [msg.from, msg.to].sort();
    const key = pair.join(' <-> ');
    if (!threadMap[key]) {
      threadMap[key] = { pairKey: key, agents: pair, messages: [] };
    }
    threadMap[key].messages.push(msg);
  });
  // Sort messages within each thread chronologically
  Object.values(threadMap).forEach(thread => {
    thread.messages.sort((a, b) => a.timestamp - b.timestamp);
    thread.lastMessage = thread.messages[thread.messages.length - 1];
    thread.count = thread.messages.length;
    thread.unreadCount = thread.messages.filter(m => !m.read).length;
  });
  // Sort threads by most recent message first
  return Object.values(threadMap).sort(
    (a, b) => b.lastMessage.timestamp - a.lastMessage.timestamp
  );
}

export function LiveCommunication({ teams, allInboxes = {} }) {
  const { t } = useTranslation();
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [autoScroll, setAutoScroll] = useState(true);
  const [fetchedInboxes, setFetchedInboxes] = useState(null);
  const [fetchError, setFetchError] = useState(null);
  const [viewMode, setViewMode] = useState('flat'); // 'flat' | 'threads'
  const [expandedThread, setExpandedThread] = useState(null); // pairKey of expanded thread
  const messagesEndRef = React.useRef(null);

  const hasWsData = Object.keys(allInboxes).length > 0;
  const source = hasWsData ? allInboxes : (fetchedInboxes || {});

  // Fetch from REST when WebSocket data is absent
  useEffect(() => {
    if (hasWsData) return;
    let cancelled = false;
    apiFetch('/api/inboxes')
      .then(r => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); })
      .then(data => { if (!cancelled) { setFetchedInboxes(data.inboxes || {}); setFetchError(null); } })
      .catch(err => {
        if (!cancelled) {
          console.error('LiveCommunication fetch error:', err);
          setFetchError(err.message || t('live_communication.failed_to_load'));
        }
      });
    return () => { cancelled = true; };
  }, [hasWsData]);

  const teamNames = useMemo(() => {
    const fromProps = (teams || []).map(t => t.name).filter(Boolean);
    const fromInboxes = Object.keys(source);
    return [...new Set([...fromProps, ...fromInboxes])];
  }, [teams, source]);

  // Auto-select first team
  useEffect(() => {
    if (teamNames.length > 0 && !selectedTeam) {
      setSelectedTeam(teamNames[0]);
    }
  }, [teamNames, selectedTeam]);

  const messages = useMemo(() => buildMessages(source, selectedTeam), [source, selectedTeam]);
  const threads = useMemo(() => buildThreads(messages), [messages]);

  // Reset expanded thread when switching teams or view modes
  useEffect(() => { setExpandedThread(null); }, [selectedTeam, viewMode]);

  useEffect(() => {
    if (autoScroll && messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, autoScroll, expandedThread]);

  const currentTeam = teams?.find(t => t.name === selectedTeam);

  const renderFlatView = () => (
    <div className="flex-1 overflow-y-auto space-y-2 mb-4" style={{ minHeight: 0 }}>
      {messages.length === 0 ? (
        <div className="text-center py-8" style={{ color: 'var(--text-muted)' }}>
          <MessageSquare aria-hidden="true" className="h-12 w-12 mx-auto mb-2 opacity-50" />
          <p className="text-sm">{t("live_communication.no_messages")}</p>
          <p className="text-xs mt-1">{t("live_communication.no_messages_description")}</p>
        </div>
      ) : (
        messages.map(msg => {
          const Icon = getIconComponent(msg.type); // lgtm[js/call-to-non-callable]
          const typeColorStyles = {
            idle: { background: 'rgba(107,114,128,0.1)', borderColor: 'rgba(107,114,128,0.3)' },
            success: { background: 'rgba(34,197,94,0.1)', borderColor: 'rgba(34,197,94,0.3)' },
            system: { background: 'rgba(234,179,8,0.1)', borderColor: 'rgba(234,179,8,0.3)' },
            working: { background: 'rgba(59,130,246,0.1)', borderColor: 'rgba(59,130,246,0.3)' },
            message: { background: 'rgba(107,114,128,0.1)', borderColor: 'rgba(107,114,128,0.3)' },
          };
          return (
            <div
              key={msg.id}
              className="p-3 rounded-lg border transition-all hover:shadow-lg"
              style={typeColorStyles[msg.type] || typeColorStyles.message}
            >
              <div className="flex items-start gap-3">
                <div className={`mt-0.5 flex-shrink-0 ${msg.type === 'success' ? 'text-green-400' :
                    msg.type === 'system' ? 'text-yellow-400' :
                      msg.type === 'working' ? 'text-blue-400' :
                        msg.type === 'idle' ? 'text-gray-400' :
                          'text-claude-orange'
                  }`}>
                  <Icon aria-hidden="true" className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold" style={{ color: 'var(--text-heading)' }}>{msg.from}</span>
                      {msg.to && msg.from !== msg.to && (
                        <>
                          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>&rarr;</span>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{msg.to}</span>
                        </>
                      )}
                      {!msg.read && (
                        <span className="text-xs text-blue-300 px-2 py-0.5 rounded-full" style={{ background: 'rgba(59,130,246,0.3)' }}>{t("live_communication.new_badge")}</span>
                      )}
                    </div>
                    <span className="text-xs whitespace-nowrap ml-2" style={{ color: 'var(--text-muted)' }}>
                      {dayjs(msg.timestamp).fromNow()}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed break-words" style={{ color: 'var(--text-primary)' }}>{msg.message}</p>
                </div>
              </div>
            </div>
          );
        })
      )}
      <div ref={messagesEndRef} />
    </div>
  );

  const renderThreadList = () => (
    <div className="flex-1 overflow-y-auto space-y-2 mb-4" style={{ minHeight: 0 }}>
      {threads.length === 0 ? (
        <div className="text-center py-8" style={{ color: 'var(--text-muted)' }}>
          <Layers aria-hidden="true" className="h-12 w-12 mx-auto mb-2 opacity-50" />
          <p className="text-sm">{t("live_communication.no_threads")}</p>
          <p className="text-xs mt-1">{t("live_communication.no_threads_description")}</p>
        </div>
      ) : (
        threads.map(thread => (
          <button
            key={thread.pairKey}
            onClick={() => setExpandedThread(thread.pairKey)}
            className="w-full text-left p-3 rounded-lg border hover:border-claude-orange transition-all cursor-pointer"
            style={{ background: 'var(--glass-bg)', borderColor: 'var(--border-color)' }}
          >
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <MessageSquare aria-hidden="true" className="h-4 w-4 text-claude-orange flex-shrink-0" />
                <span className="text-sm font-semibold" style={{ color: 'var(--text-heading)' }}>
                  {thread.agents[0]} &#8596; {thread.agents[1]}
                </span>
                {thread.unreadCount > 0 && (
                  <span className="text-xs text-blue-300 px-2 py-0.5 rounded-full" style={{ background: 'rgba(59,130,246,0.3)' }}>
                    {thread.unreadCount} {t("live_communication.new_badge").toLowerCase()}
                  </span>
                )}
              </div>
              <span className="text-xs whitespace-nowrap" style={{ color: 'var(--text-muted)' }}>
                {dayjs(thread.lastMessage.timestamp).fromNow()}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <p className="text-xs truncate mr-4" style={{ color: 'var(--text-secondary)', maxWidth: '70%' }}>
                {thread.lastMessage.message}
              </p>
              <span className="text-xs flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
                {thread.count} message{thread.count !== 1 ? 's' : ''}
              </span>
            </div>
          </button>
        ))
      )}
      <div ref={messagesEndRef} />
    </div>
  );

  const renderExpandedThread = () => {
    const thread = threads.find(t => t.pairKey === expandedThread);
    if (!thread) return null;
    // In the expanded view, pick one agent as "self" (the second alphabetically)
    // Messages FROM agents[0] show on left (gray), FROM agents[1] show on right (orange)
    const [leftAgent, rightAgent] = thread.agents;

    return (
      <div className="flex-1 overflow-y-auto mb-4 flex flex-col" style={{ minHeight: 0 }}>
        {/* Thread header */}
        <div className="flex items-center gap-2 mb-3 pb-2" style={{ borderBottom: '1px solid var(--border-color)' }}>
          <button
            onClick={() => setExpandedThread(null)}
            className="p-1 rounded transition-colors"
            style={{ color: 'var(--text-muted)' }}
            aria-label={t('live_communication.back_label')}
          >
            <ChevronLeft aria-hidden="true" className="h-4 w-4" />
          </button>
          <span className="text-sm font-semibold" style={{ color: 'var(--text-heading)' }}>
            {leftAgent} &#8596; {rightAgent}
          </span>
          <span className="text-xs ml-auto" style={{ color: 'var(--text-muted)' }}>
            {thread.count} message{thread.count !== 1 ? 's' : ''}
          </span>
        </div>

        {/* Chat bubbles */}
        <div className="flex-1 overflow-y-auto space-y-2 px-1">
          {thread.messages.map(msg => {
            const isRight = msg.from === rightAgent;
            return (
              <div
                key={msg.id}
                className={`flex ${isRight ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className="px-3 py-2 rounded-lg border"
                  style={isRight
                    ? { maxWidth: '75%', background: 'rgba(232,117,10,0.2)', borderColor: 'rgba(232,117,10,0.4)' }
                    : { maxWidth: '75%', background: 'var(--glass-bg)', borderColor: 'var(--border-color)' }
                  }
                >
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className={`text-xs font-semibold ${isRight ? 'text-orange-300' : ''}`}
                      style={!isRight ? { color: 'var(--text-secondary)' } : undefined}
                    >
                      {msg.from}
                    </span>
                    <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                      {dayjs(msg.timestamp).fromNow()}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed break-words" style={{ color: 'var(--text-primary)' }}>{msg.message}</p>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>
    );
  };

  return (
    <div className="card" style={{ height: '600px', display: 'flex', flexDirection: 'column' }}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <MessageSquare aria-hidden="true" className="h-5 w-5 text-claude-orange" />
          <h3 className="text-lg font-semibold" style={{ color: 'var(--text-heading)' }}>{t("live_communication.title")}</h3>
        </div>
        <div className="flex items-center gap-3">
          {/* View Toggle */}
          <div className="flex items-center rounded-lg p-0.5" style={{ background: 'var(--bg-secondary)' }}>
            <button
              onClick={() => setViewMode('flat')}
              className="flex items-center gap-1 text-xs px-2 py-1 rounded transition-colors"
              style={viewMode === 'flat'
                ? { background: 'rgba(232,117,10,0.2)', color: 'var(--claude-orange)' }
                : { color: 'var(--text-muted)' }
              }
              title={t("live_communication.flat_view")}
              aria-pressed={viewMode === 'flat'}
            >
              <List aria-hidden="true" className="h-3 w-3" />
              {t("live_communication.flat_view")}
            </button>
            <button
              onClick={() => setViewMode('threads')}
              className="flex items-center gap-1 text-xs px-2 py-1 rounded transition-colors"
              style={viewMode === 'threads'
                ? { background: 'rgba(232,117,10,0.2)', color: 'var(--claude-orange)' }
                : { color: 'var(--text-muted)' }
              }
              title={t("live_communication.threads_view")}
              aria-pressed={viewMode === 'threads'}
            >
              <Layers aria-hidden="true" className="h-3 w-3" />
              {t("live_communication.threads_view")}
            </button>
          </div>
          <button
            onClick={() => setAutoScroll(!autoScroll)}
            className="text-xs px-2 py-1 rounded transition-colors"
            style={autoScroll
              ? { background: 'rgba(34,197,94,0.2)', color: '#4ade80' }
              : { background: 'var(--bg-secondary)', color: 'var(--text-muted)' }
            }
            aria-pressed={autoScroll}
            aria-label={autoScroll ? t('live_communication.disable_scroll') : t('live_communication.enable_scroll')}
          >
            {autoScroll ? t('live_communication.auto_scroll') : t('live_communication.scroll_locked')}
          </button>
          <span className="text-xs text-green-400 flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse"></span>
            {t("live_metrics.live")}
          </span>
        </div>
      </div>

      {/* Team Selector */}
      {teamNames.length > 0 && (
        <div className="mb-4">
          <label htmlFor="live-comm-team-select" className="sr-only">{t("live_communication.select_team")}</label>
          <select
            id="live-comm-team-select"
            value={selectedTeam || ''}
            onChange={e => setSelectedTeam(e.target.value)}
            className="w-full px-3 py-2 rounded-lg focus:border-claude-orange focus:outline-none"
            style={{ background: 'var(--bg-secondary)', color: 'var(--text-heading)', border: '1px solid var(--border-color)' }}
          >
            {teamNames.map(name => {
              const team = teams?.find(t => t.name === name);
              const agentCount = team?.config?.members?.length
                || Object.keys(source[name] || {}).length;
              return (
                <option key={name} value={name}>
                  {name} ({agentCount} {team ? 'members' : 'agents'})
                </option>
              );
            })}
          </select>
        </div>
      )}

      {/* Error display */}
      {fetchError && (
        <div role="alert" className="mb-4 p-3 rounded-lg text-sm" style={{ color: 'var(--text-muted)', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)' }}>
          Error loading data: {fetchError}
        </div>
      )}

      {/* Content Area - switches between flat, thread list, and expanded thread */}
      {viewMode === 'flat'
        ? renderFlatView()
        : expandedThread
          ? renderExpandedThread()
          : renderThreadList()
      }

      {/* Team Info */}
      {currentTeam && (
        <div className="pt-4" style={{ borderTop: '1px solid var(--border-color)' }}>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
              <Users aria-hidden="true" className="h-4 w-4" />
              <span>{currentTeam.config?.members?.length || 0} members</span>
            </div>
            <div className="flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
              <Clock aria-hidden="true" className="h-4 w-4" />
              <span>{currentTeam.tasks?.filter(t => t.status === 'in_progress').length || 0} active</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}