import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Crown, Cpu, Zap } from 'lucide-react';
import { getAgentInitials, getAgentColor } from "../utils/formatting";
import { useTranslation } from 'react-i18next';

const TAILWIND_TO_HEX = {
  'bg-blue-600': '#2563eb',
  'bg-purple-600': '#9333ea',
  'bg-green-600': '#16a34a',
  'bg-red-600': '#dc2626',
  'bg-yellow-600': '#ca8a04',
  'bg-pink-600': '#db2777',
  'bg-indigo-600': '#4f46e5',
  'bg-orange-500': '#f97316',
};

export function AgentCard({ agent, isLead, agentStatus }) {
  const [isHovered, setIsHovered] = useState(false);
  const [statusHovered, setStatusHovered] = useState(false);

  const agentColorClass = getAgentColor(agent?.name);
  const avatarHex = TAILWIND_TO_HEX[agentColorClass] ?? '#6b7280';
  const {t} = useTranslation();
  return (
    <div
      className="p-5"
      role="article"
      tabIndex={0}
      aria-label={
  isLead
    ? t("agent_card.agent_lead_label", { name: agent.name })
    : t("agent_card.agent_label", { name: agent.name })
}
      style={{
        position: 'relative',
        borderRadius: '16px',
        transition: 'all 0.3s',
        background: isLead
          ? 'linear-gradient(135deg, rgba(234, 179, 8, 0.12) 0%, rgba(202, 138, 4, 0.08) 100%)'
          : 'linear-gradient(135deg, rgba(59, 130, 246, 0.12) 0%, rgba(37, 99, 235, 0.08) 100%)',
        border: `2px solid ${isLead ? 'rgba(234, 179, 8, 0.3)' : 'rgba(59, 130, 246, 0.25)'}`,
        boxShadow: isHovered
          ? `0 8px 24px ${isLead ? 'rgba(234, 179, 8, 0.25)' : 'rgba(59, 130, 246, 0.2)'}, inset 0 1px 0 rgba(255, 255, 255, 0.1)`
          : 'var(--card-shadow)',
        transform: isHovered ? 'translateY(-4px) scale(1.02)' : 'translateY(0) scale(1)',
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
    >
      <div
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: '16px',
          opacity: isHovered ? 1 : 0,
          transition: 'opacity 0.5s',
          background: isLead
            ? 'linear-gradient(135deg, rgba(234, 179, 8, 0.2), transparent 50%, rgba(234, 179, 8, 0.1))'
            : 'linear-gradient(135deg, rgba(59, 130, 246, 0.2), transparent 50%, rgba(59, 130, 246, 0.1))',
          pointerEvents: 'none',
        }}
      />

      <div className="flex items-start justify-between" style={{ position: 'relative', zIndex: 10 }}>
        <div className="flex items-start gap-4 flex-1">

          {/* Avatar Circle */}
          <div
            style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 'bold',
              fontSize: '14px',
              color: '#ffffff',
              border: isLead ? '2px solid #facc15' : '2px solid transparent',
              backgroundColor: avatarHex,
              boxShadow: isHovered ? `0 0 12px ${avatarHex}` : 'none',
              position: 'relative',
              transition: 'all 0.3s',
              flexShrink: 0,
            }}
          >
            {getAgentInitials(agent?.name)}

            {isLead && (
              <Crown
                size={12}
                style={{
                  position: 'absolute',
                  top: '-4px',
                  right: '-4px',
                  background: 'var(--bg-card)',
                  borderRadius: '50%',
                  padding: '2px',
                  color: '#facc15',
                }}
              />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              {agentStatus && (
                <div
                  role="img"
                  aria-label={agentStatus.tooltipText}
                  tabIndex={0}
                  style={{ position: 'relative' }}
                  title={agentStatus.tooltipText}
                  onMouseEnter={() => setStatusHovered(true)}
                  onMouseLeave={() => setStatusHovered(false)}
                  onFocus={() => setStatusHovered(true)}
                  onBlur={() => setStatusHovered(false)}
                >
                  <span
                    className={`inline-block rounded-full ${agentStatus.pulse ? 'animate-pulse' : ''}`}
                    style={{
                      width: '10px',
                      height: '10px',
                      flexShrink: 0,
                      backgroundColor: agentStatus.color,
                      boxShadow: agentStatus.pulse ? `0 0 8px ${agentStatus.color}` : 'none',
                    }}
                  />
                  <div
                    style={{
                      position: 'absolute',
                      bottom: '100%',
                      left: '50%',
                      transform: 'translateX(-50%)',
                      marginBottom: '8px',
                      padding: '4px 8px',
                      background: 'var(--bg-card)',
                      fontSize: '12px',
                      color: 'var(--text-primary)',
                      borderRadius: '4px',
                      whiteSpace: 'nowrap',
                      zIndex: 20,
                      border: '1px solid var(--border-color)',
                      opacity: statusHovered ? 1 : 0,
                      transition: 'opacity 0.15s',
                      pointerEvents: 'none',
                    }}
                  >
                    {agentStatus.tooltipText}
                  </div>
                </div>
              )}

              <h5
                className="font-bold text-lg truncate"
                style={{
                  color: 'var(--text-heading)',
                  letterSpacing: '-0.01em',
                }}
              >
                {agent.name}
              </h5>

              {isLead && (
                <span
                  className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold tracking-wider"
                  style={{
                    textTransform: 'uppercase',
                    gap: '6px',
                    background: 'linear-gradient(135deg, rgba(234, 179, 8, 0.3) 0%, rgba(202, 138, 4, 0.2) 100%)',
                    color: '#facc15',
                    border: '1px solid rgba(234, 179, 8, 0.5)',
                    boxShadow: '0 2px 8px rgba(234, 179, 8, 0.3)',
                  }}
                >
                  <Zap className="h-3 w-3" aria-hidden="true" />
                 { t('agent_card.lead')}
                </span>
              )}
            </div>

            {agent.agentType && (
              <div
                className="flex items-center gap-2 mb-2 py-1 rounded-lg"
                style={{
                  paddingLeft: '10px',
                  paddingRight: '10px',
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                }}
              >
                <Cpu className="h-4 w-4" aria-hidden="true" style={{ color: 'var(--text-secondary)' }} />
                <span className="text-sm truncate font-medium" style={{ color: 'var(--text-muted)' }}>
                  {agent.agentType}
                </span>
              </div>
            )}

            <p
              className="text-xs truncate"
              style={{
                fontFamily: 'monospace',
                color: 'var(--text-muted)',
              }}
              title={agent.agentId}
            >
              {t('agent_card.id_prefix')}: {agent.agentId?.substring(0, 12)}...
            </p>
          </div>
        </div>
      </div>

      {isHovered && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            borderRadius: '16px',
            pointerEvents: 'none',
            background: 'linear-gradient(135deg, transparent 0%, rgba(255, 255, 255, 0.05) 50%, transparent 100%)',
            animation: 'shimmer 2s ease-in-out infinite',
          }}
        />
      )}
    </div>
  );
}

AgentCard.propTypes = {
  agent: PropTypes.shape({
    name: PropTypes.string.isRequired,
    agentId: PropTypes.string.isRequired,
    agentType: PropTypes.string,
    model: PropTypes.string,
  }).isRequired,
  isLead: PropTypes.bool,
  agentStatus: PropTypes.shape({
    status: PropTypes.string,
    color: PropTypes.string,
    label: PropTypes.string,
    dot: PropTypes.string,
    pulse: PropTypes.bool,
    tooltipText: PropTypes.string,
  }),
};
